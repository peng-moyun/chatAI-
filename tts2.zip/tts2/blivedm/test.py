import os
# path = os.path.exists('user.py')
if False == os.path.exists('test_file.txt.txt'):
    print(os.path.exists('user.py'))
else:
    print("存在")